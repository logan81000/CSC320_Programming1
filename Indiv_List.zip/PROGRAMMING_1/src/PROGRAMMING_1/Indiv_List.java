package PROGRAMMING_1;

public class Indiv_List {
	public static void main(String[] arg) {
		System.out.println("David");
		System.out.println("Valitin");
		System.out.println("562 Letterman St");
		System.out.println("Garytown");
		System.out.println("42598");
		
	}

}
